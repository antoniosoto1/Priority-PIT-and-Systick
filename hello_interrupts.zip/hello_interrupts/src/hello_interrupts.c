/*
 * hello_interrupts.c              Copyright NXP 2016
 * Description: Minimal interrupt example using LPIT0 chan 0 (vector 64)
 * 2016 Mar 04 S Mihalik - Initial Version
 * 2016 Oct 27 SM - Changed LPIT0 count & updated for S32DS v 1.3 header files
 * 2017 Jan 23 SM - Corrected FSL_NVIC->IP[48] value to have priority 10
 * 2017 Jun 30 SM - Changed IRQ handler sequence to ensure flag cleared
 * 2017 Jul 17 SM - Changed NVIC reg name prefix per new header files in v 1.3
 */

#include "S32K144.h"          /* include peripheral declarations S32K144 */
#include "clocks_and_modes.h"

void EnableInterrupts(void);  // Enable interrupts
void SysTick_Init(void);
void WDOG_disable (void);

int lpit0_ch0_flag_counter = 0; /* LPIT0 chan 0 timeout counter */
int lpit0_ch1_flag_counter=0;
/*0 blue, 15 RED, 16 Green */
#define LED_GREEN  16
#define LED_RED  15
#define LED_BLUE  0

volatile unsigned long Counts = 0;


/*
** ===================================================================
**     Method      :  WaitCycles (component Wait)
**
**     Description :
**         Wait for a specified number of CPU cycles (16bit data type).
**     Parameters  :
**         NAME            - DESCRIPTION
**         cycles          - The number of cycles to wait.
**     Returns     : Nothing
** ===================================================================
*/
void McuWait_WaitCycles(uint16_t cycles)
{
  /*lint -save -e522 function lacks side effect. */
  while(cycles > 100) {
    McuWait_Wait100Cycles();
    cycles -= 100;
  }
  while(cycles > 10) {
    McuWait_Wait10Cycles();
    cycles -= 10;
  }
  /*lint -restore */
}

/*
** ===================================================================
**     Method      :  WaitLongCycles (component Wait)
**
**     Description :
**         Wait for a specified number of CPU cycles (32bit data type).
**     Parameters  :
**         NAME            - DESCRIPTION
**         cycles          - The number of cycles to wait.
**     Returns     : Nothing
** ===================================================================
*/
void McuWait_WaitLongCycles(uint32_t cycles)
{
  /*lint -save -e522 function lacks side effect. */
  while(cycles>60000) {
    McuWait_WaitCycles(60000);
    cycles -= 60000;
  }
  McuWait_WaitCycles((uint16_t)cycles);
  /*lint -restore */
}

/*
** ===================================================================
**     Method      :  Waitms (component Wait)
**
**     Description :
**         Wait for a specified time in milliseconds.
**     Parameters  :
**         NAME            - DESCRIPTION
**         ms              - How many milliseconds the function has to
**                           wait
**     Returns     : Nothing
** ===================================================================
*/
void McuWait_Waitms(uint16_t ms)
{
  /*lint -save -e522 function lacks side effect. */
  uint32_t msCycles; /* cycles for 1 ms */

  /* static clock/speed configuration */
  msCycles = McuWait_NofCyclesMs(1, McuWait_INSTR_CLOCK_HZ);
  while(ms>0) {
    McuWait_WaitLongCycles(msCycles);
    ms--;
  }
  /*lint -restore */
}



void NVIC_init_IRQs (void) {
//	CH0 LED_RED
//  S32_NVIC->ICPR[1] = 1 << (48 % 32);  /* IRQ48-LPIT0 ch0: LED_RED clr any pending IRQ*/
//  S32_NVIC->ISER[1] = 1 << (48 % 32);  /* IRQ48-LPIT0 ch0: LED_RED enable IRQ */
//  S32_NVIC->IP[48] = 0xA0;             /* IRQ48-LPIT0 ch0: LED_RED priority 10 of 0-15*/
//  CH1 LED_GREEN
  S32_NVIC->ICPR[1] = 1 << (49 % 32);  /* IRQ49-LPIT0 ch1: LED_GREEN clr any pending IRQ*/
  S32_NVIC->ISER[1] = 1 << (49 % 32);  /* IRQ49-LPIT0 ch1: LED_GREEN enable IRQ */
  S32_NVIC->IP[49] = 0xA0;             /* IRQ49-LPIT0 ch1: LED_GREEN priority 10 of 0-15*/
}

void PORT_init (void) {
  PCC-> PCCn[PCC_PORTD_INDEX] = PCC_PCCn_CGC_MASK; /* Enable clock for PORT D */
  PTD->PDDR |= 1<<LED_GREEN;             /* Port D0:  Data Direction= output */
  PORTD->PCR[LED_GREEN] =  	0x00000100;  /* Port D0:  MUX = ALT1, GPIO ([0] blue,[15] RED ,[16] Green LED on EVB ) */
  PTD->PDDR |= 1<<LED_RED;
  PORTD->PCR[LED_RED] =  	0x00000100;
  PTD->PDDR |= 1<<LED_BLUE;
  PORTD->PCR[LED_BLUE] =  	0x00000100;
}

void LPIT0_init (void) {
  PCC->PCCn[PCC_LPIT_INDEX] = PCC_PCCn_PCS(6);    /* Clock Src = 6 (SPLL2_DIV2_CLK)*/
  PCC->PCCn[PCC_LPIT_INDEX] |= PCC_PCCn_CGC_MASK; /* Enable clk to LPIT0 regs */
  LPIT0->MCR = 0x00000001;    /* DBG_EN-0: Timer chans stop in Debug mode */
                              /* DOZE_EN=0: Timer chans are stopped in DOZE mode */
                              /* SW_RST=0: SW reset does not reset timer chans, regs */
                           /* M_CEN=1: enable module clk (allows writing other LPIT0 regs)*/
  /*LPTI CH0*/
//  LPIT0->MIER = 0x00000001;   /* TIE0=1: Timer Interrupt Enabled fot Chan 0 */
//  LPIT0->TMR[0].TVAL = 1000000;    /* Chan 0 Timeout period: 40M clocks */
//  LPIT0->TMR[0].TCTRL = 0x00000001; /* T_EN=1: Timer channel is enabled */
  /*LPTI CH1*/
  LPIT0->MIER |= 0x00000002;
  LPIT0->TMR[1].TVAL = 3000000;
  LPIT0->TMR[1].TCTRL = 0x10000001;

}
void WDOG_disable (void){
  WDOG->CNT=0xD928C520; 	/*Unlock watchdog*/
  WDOG->TOVAL=0x0000FFFF;	/*Maximum timeout value*/
  WDOG->CS = 0x00002100;    /*Disable watchdog*/
}


int main(void) {
//	int waitms_main = 1;
	WDOG_disable();
	PORT_init();             /* Configure ports */
	SOSC_init_8MHz();        /* Initialize system oscilator for 8 MHz xtal */
	SPLL_init_160MHz();      /* Initialize SPLL to 160 MHz with 8 MHz SOSC */
	NormalRUNmode_80MHz();   /* Init clocks: 80 MHz sysclk & core, 40 MHz bus, 20 MHz flash */
	NVIC_init_IRQs();        /* Enable desired interrupts and priorities */
	LPIT0_init();            /* Initialize PIT0 for 1 second timeout  */
	SysTick_Init();        // SysTick timer Init

	EnableInterrupts();
	while(1){

//		PTD->PTOR |= 1<<LED_RED;                /* Toggle output on port  */
//		McuWait_Waitms(waitms_main) ;

  }
}

void LPIT0_Ch1_IRQHandler (void) {
//	int flag_counter=0;
	int waitms = 40;

	LPIT0->MSR |= LPIT_MSR_TIF1_MASK; /* Clear LPIT1 timer flag 0 */
			  /* Perform read-after-write to ensure flag clears before ISR exit */
	lpit0_ch1_flag_counter++;         /* Increment LPIT0 timeout counter */
	PTD->PTOR |= 1<<LED_GREEN;                /* Toggle output on port  */


//	while (flag_counter<=(70/waitms))
//	 {
	PTD->PTOR |= 1<<LED_BLUE;
	McuWait_Waitms(waitms) ;
	PTD->PTOR |= 1<<LED_BLUE;
//	 	flag_counter++;
//	 }

}

void LPIT0_Ch0_IRQHandler (void) {
  LPIT0->MSR |= LPIT_MSR_TIF0_MASK; /* Clear LPIT1 timer flag 0 */
//  PTD->PTOR |= 1<<LED_RED;                /* Toggle output on port  */
}

void SysTick_Handler(void){
	PTD->PTOR |= 1<<LED_RED;                /* Toggle PD15 (LED RED) Port Toggle Output Register (PTOR) */
}
