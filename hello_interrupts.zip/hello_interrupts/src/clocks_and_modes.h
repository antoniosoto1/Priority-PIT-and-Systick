#ifndef CLOCKS_AND_MODES_H_
#define CLOCKS_AND_MODES_H_

void SOSC_init_8MHz (void);
void SPLL_init_160MHz (void);
void NormalRUNmode_80MHz (void);


#define McuWait_INSTR_CLOCK_HZ       80000000  /* core clock frequency in Hz */

#define McuWait_NofCyclesMs(ms, hz)  ((ms)*((hz)/1000)) /* calculates the needed cycles based on bus clock frequency */
#define McuWait_NofCyclesUs(us, hz)  ((us)*(((hz)/1000)/1000)) /* calculates the needed cycles based on bus clock frequency */
#define McuWait_NofCyclesNs(ns, hz)  (((ns)*(((hz)/1000)/1000))/1000) /* calculates the needed cycles based on bus clock frequency */

#define McuWait_WAIT_C(cycles) \
     ( (cycles)<=10 ? \
          McuWait_Wait10Cycles() \
        : McuWait_WaitCycles((uint16_t)cycles) \
      )                                      /*!< wait for some cycles */


void McuWait_Wait10Cycles(void);
/*
** ===================================================================
**     Method      :  Wait10Cycles (component Wait)
**
**     Description :
**         Wait for 10 CPU cycles.
**     Parameters  : None
**     Returns     : Nothing
** ===================================================================
*/

void McuWait_Wait100Cycles(void);
/*
** ===================================================================
**     Method      :  Wait100Cycles (component Wait)
**
**     Description :
**         Wait for 100 CPU cycles.
**     Parameters  : None
**     Returns     : Nothing
** ===================================================================
*/

void McuWait_WaitCycles(uint16_t cycles);
/*
** ===================================================================
**     Method      :  WaitCycles (component Wait)
**
**     Description :
**         Wait for a specified number of CPU cycles (16bit data type).
**     Parameters  :
**         NAME            - DESCRIPTION
**         cycles          - The number of cycles to wait.
**     Returns     : Nothing
** ===================================================================
*/

void McuWait_Waitms(uint16_t ms);
/*
** ===================================================================
**     Method      :  Waitms (component Wait)
**
**     Description :
**         Wait for a specified time in milliseconds.
**     Parameters  :
**         NAME            - DESCRIPTION
**         ms              - How many milliseconds the function has to
**                           wait
**     Returns     : Nothing
** ===================================================================
*/

/* we are having a static clock configuration: implement as macro/inlined version */
#define McuWait_Waitus(us)  \
        /*lint -save -e(505,506,522) Constant value Boolean, Redundant left argument to comma. */\
       (  ((McuWait_NofCyclesUs((us),McuWait_INSTR_CLOCK_HZ)==0)||(us)==0) ? \
          (void)0 : \
          ( ((us)/1000)==0 ? (void)0 : McuWait_Waitms((uint16_t)((us)/1000))) \
          , (McuWait_NofCyclesUs(((us)%1000), McuWait_INSTR_CLOCK_HZ)==0) ? (void)0 : \
            McuWait_WAIT_C(McuWait_NofCyclesUs(((us)%1000), McuWait_INSTR_CLOCK_HZ)) \
       /*lint -restore */\
       )
/*
** ===================================================================
**     Method      :  Waitus (component Wait)
**
**     Description :
**         Wait for a specified time in microseconds.
**     Parameters  :
**         NAME            - DESCRIPTION
**         us              - How many microseconds the function has to
**                           wait
**     Returns     : Nothing
** ===================================================================
*/

/* we are having a static clock configuration: implement as macro/inlined version */
#define McuWait_Waitns(ns)  \
        /*lint -save -e(505,506,522) Constant value Boolean, Redundant left argument to comma. */\
       (  ((McuWait_NofCyclesNs((ns), McuWait_INSTR_CLOCK_HZ)==0)||(ns)==0) ? \
          (void)0 : \
          McuWait_Waitus((ns)/1000) \
          , (McuWait_NofCyclesNs((ns)%1000, McuWait_INSTR_CLOCK_HZ)==0) ? \
              (void)0 : \
              McuWait_WAIT_C(McuWait_NofCyclesNs(((ns)%1000), McuWait_INSTR_CLOCK_HZ)) \
       /*lint -restore */\
       )
/*
** ===================================================================
**     Method      :  Waitns (component Wait)
**
**     Description :
**         Wait for a specified time in nano seconds.
**     Parameters  :
**         NAME            - DESCRIPTION
**         ns              - How many ns the function has to wait
**     Returns     : Nothing
** ===================================================================
*/

#if McuWait_CONFIG_USE_RTOS_WAIT
  #define McuWait_WaitOSms(ms) vTaskDelay(pdMS_TO_TICKS(ms)) /* use FreeRTOS API */
#else
  #define McuWait_WaitOSms(ms)  McuWait_Waitms(ms) /* use normal wait */
#endif
/*
** ===================================================================
**     Method      :  WaitOSms (component Wait)
**
**     Description :
**         If an RTOS is enabled, this routine will use a non-blocking
**         wait method. Otherwise it will do a busy/blocking wait.
**     Parameters  : None
**     Returns     : Nothing
** ===================================================================
*/

void McuWait_WaitLongCycles(uint32_t cycles);
/*
** ===================================================================
**     Method      :  WaitLongCycles (component Wait)
**
**     Description :
**         Wait for a specified number of CPU cycles (32bit data type).
**     Parameters  :
**         NAME            - DESCRIPTION
**         cycles          - The number of cycles to wait.
**     Returns     : Nothing
** ===================================================================
*/

void McuWait_Init(void);
/*
** ===================================================================
**     Method      :  Init (component Wait)
**
**     Description :
**         Driver initialization routine.
**     Parameters  : None
**     Returns     : Nothing
** ===================================================================
*/

void McuWait_DeInit(void);

#endif /* CLOCKS_AND_MODES_H_ */

